# AGENTS.md

## Branch and scope

- The static site is the **`github-pages`** branch. A fresh clone defaults to `main`, which is the older FastAPI/desktop build (`requirements.txt`, `run.py`, `app/*.py`); do not copy that branch's files or commands into this branch.
- This branch is pure static HTML/CSS/JS: no build step, package manager, linter, or CI. Tests use Node's built-in runner.
- Tracked runtime files are `index.html`, `styles.css`, `js/`, `assets/`, and `.nojekyll`. Ignored leftovers from the old backend (`.pyc`, SQLite, `logs/`) still sit in `app/`, `tests/`, `data/`, and `logs/` — do not edit or commit those artifacts.

## Run and verify

- Serve the repository root and open the printed URL:
  ```powershell
  python -m http.server 8000
  # http://127.0.0.1:8000
  ```
- Use a local server, not `file://`: translations and the default library are loaded with relative `fetch()` calls.
- Syntax-check changed scripts with `node --check js/<file>.js`.
- Run the back-to-top unit tests with `node --test tests/scroll-top.test.js` (or `node --test` for the whole JS suite). Smoke-test UI changes in a browser (search, editor clean/copy, library, settings) and watch the console.
- To reproduce a first run / reload bundled defaults, clear the app's `localStorage` keys (`danbooru-pages.*`, `danbooru-standalone-*`, `gelbooru-standalone-*`); otherwise cached settings, library, and UI state hide asset changes.

## Architecture

- Scripts are plain globals (no ES modules) and depend on `index.html` order:
  `translations.js` → `prompt-clean.js` → `gallery-api.js` → `store.js` → `core.js` → `scroll-top.js` → `search.js` → `editor.js` → `library.js` → `bootstrap.js`.
- `core.js` declares shared globals `state`, `elements`, and `api()`. Add new DOM nodes to `index.html` and cache their IDs in `elements`; later scripts assume they exist.
- `bootstrap.js` binds events and immediately calls `init()`. Keep it last and do not add an independent init path in earlier scripts.
- `scroll-top.js` owns back-to-top visibility and scrolling; `goToPage()` calls it so every real page change returns to the top. Keep its threshold/behavior in sync with `tests/scroll-top.test.js`.
- All data access goes through `api()`, which routes `/api/*` to the browser-side router in `store.js`, not to a backend. Add new endpoints to `store.js` and expose the implementation under `DG.*`.
- `gallery-api.js` calls Danbooru/Gelbooru directly and normalizes upstream fields; `search.js` owns search/pagination/favorites; `editor.js` prompt editing; `library.js` prompt-library UI.
- `translations.js` and `prompt-clean.js` are browser ports of removed Python helpers. Keep prompt-clean option names snake_case (`underscore_to_space`, `remove_lora_tags`, etc.); `editor.js` posts those exact names.

## Persistence and assets

- Settings: `danbooru-pages.settings`. Prompt library: `danbooru-pages.library`. UI prefs/favorites: `danbooru-standalone-*` and `gelbooru-standalone-*`.
- `DEFAULT_SETTINGS` in `store.js` is the schema: settings passed to `/api/settings` are silently dropped if the key is not already defined there. Add new settings to `DEFAULT_SETTINGS` first.
- `assets/default_prompt_library.json` only seeds a browser on first run. Existing browsers keep `localStorage` (format v1.6); edit the asset only for new installs, and use import/export for migration.
- Translation data loads in this precedence order: `all_tags_cn.json`, then `danbooru.csv` (English→Chinese, fills gaps), then `wai_characters.csv` (reversed, Chinese→English).
- UI strings are hard-coded Simplified Chinese. The `language` field is vestigial; there is no i18n layer despite the bilingual README.
- Keep asset URLs relative so the site works under a GitHub Pages `/repo/` subpath.
- Gelbooru's `recent:Nd` filter is approximate (latest post ID minus `N × 12000`), not a real date range. The CORS proxy is retried only when the direct fetch throws, not on HTTP error statuses.

## Deploy

- Publish by pushing `github-pages`; GitHub Pages serves that branch's root directly. There is no artifact or build step to run.
- Do not introduce a bundler, package manager, or generated `dist/`; the branch is the deployable output.
